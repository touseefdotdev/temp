﻿namespace question01
{

    public class Student
    {
        public string Name;
        public int Age;

        // Default Constructor
        public Student(string nameInput, int ageInput)
        {
            Name = nameInput;
            Age = ageInput;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            // Program Header
            Console.WriteLine("~~~~~~~~ Find the list of teenage students from an array of Student objects.\n\n");
            Console.WriteLine("~~~~~~~~ Solution: \n");

            // Creating Array of Student Objects
            Student[] Students = new Student[]
            {
                new Student("Ali", 12),
                new Student("Ahmad", 13),
                new Student("Awais", 15),
                new Student("Bilal", 17),
                new Student("Basheer", 18),
                new Student("Bazil", 19),
                new Student("Danish", 20),
                new Student("Junaid", 21),
                new Student("Saad", 22)
            };

            // Printing the available students on Console
            Console.WriteLine("The Array of Student Objects Contains:");
            foreach (var item in Students)
            {
                Console.WriteLine("{0, -10} {1, -10}", item.Name, item.Age);
            }

            // Finding List of teenage students only
            var teenageStudents = from s in Students
                                  where s.Age >= 13 && s.Age <= 19 
                                  select s;

            // Printing the result on Console
            Console.WriteLine("\nThe Filtered Teenage Students are:");
            foreach (var item in teenageStudents)
            {
                Console.WriteLine("{0, -10} {1, -10}", item.Name, item.Age);
            }


            // Ending the program
            Console.WriteLine("\n~~~~~~~~ Program Finished. Press any key to exit.");
            Console.ReadKey();
        }
    }
}