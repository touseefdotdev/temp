﻿namespace question02
{
    public class Person
    {
        public string Name;
        public int Age;

        // Default Constructor
        public Person(string nameInput, int ageInput)
        {
            Name = nameInput;
            Age = ageInput;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            // Program Header
            Console.WriteLine("~~~~~~~~  Find the Names of the people that starts with the letter M from the list of the people names.\n\n");
            Console.WriteLine("~~~~~~~~ Solution: \n");

            // Creating List of Persons (People)
            List<Person> People = new List<Person>
            {
                new Person("Ali", 22),
                new Person("Mubashir", 23),
                new Person("Awais", 25),
                new Person("Bilal", 27),
                new Person("Basheer", 28),
                new Person("Mudasir", 29),
                new Person("Danish", 30),
                new Person("Junaid", 31),
                new Person("Saad", 32)
            };

            // Printing the available Persons on Console
            Console.WriteLine("The List of People Names is:");
            foreach (var item in People)
            {
                Console.WriteLine("{0, -10}", item.Name);
            }

            // Finding those people whose names start with the letter M
            var specialPeople = from p in People
                                  where p.Name.StartsWith("M")
                                  select p;

            // Printing the result on Console
            Console.WriteLine("\nThe Filtered Persons (whose names start with M) are:");
            foreach (var item in specialPeople)
            {
                Console.WriteLine("{0, -10}", item.Name);
            }


            // Ending the program
            Console.WriteLine("\n~~~~~~~~ Program Finished. Press any key to exit.");
            Console.ReadKey();
        }
    }
}