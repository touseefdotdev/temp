﻿namespace question03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Program Header
            Console.WriteLine("~~~~~~~~ Use LINQ to find the even numbers from the array.\n\n");
            Console.WriteLine("~~~~~~~~ Solution: \n");

            // Creating Array of Numbers
            int[] Numbers = new int[]
            {
                1,2,3,4,5,6,7,8,9,10,11,12
            };

            // Printing the available Numbers on Console
            Console.WriteLine("The List of Numbers is:");
            foreach (var item in Numbers)
            {
                Console.WriteLine("{0, -10}", item);
            }

            // Finding even number
            var evenNumbers = from n in Numbers
                                where (n % 2) == 0
                                select n;

            // Printing the result on Console
            Console.WriteLine("\nThe Filtered Even Numbers are:");
            foreach (var item in evenNumbers)
            {
                Console.WriteLine("{0, -10}", item);
            }


            // Ending the program
            Console.WriteLine("\n~~~~~~~~ Program Finished. Press any key to exit.");
            Console.ReadKey();
        }
    }
}